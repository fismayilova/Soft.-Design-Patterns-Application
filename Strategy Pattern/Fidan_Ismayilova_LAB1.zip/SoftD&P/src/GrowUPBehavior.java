
public interface GrowUPBehavior  {
 public void growUP();
}
