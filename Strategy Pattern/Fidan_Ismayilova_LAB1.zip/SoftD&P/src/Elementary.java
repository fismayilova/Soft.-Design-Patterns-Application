
public class Elementary extends Student {
	public Elementary(String name, int sport) {
		super(name, sport);
	}
}
