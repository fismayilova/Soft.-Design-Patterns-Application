
public class High extends Student {
	public High(String name, int sport) {
		super(name, sport);
	}
}
