
public class Middle extends Student {
	public Middle(String name, int sport) {
		super(name, sport);
	}
}
